#include <iostream>
#include <vector>

std::vector<std::pair<int,
    int>> SearchEven(std::vector<std::vector<int>> data) {
    std::vector<std::pair<int, int>> locations;
    for (int i = 0; i < data.size(); i++) {
        for (int j = 0; j < data[i].size(); j++) {
            if (data[i][j] % 2 == 0) {
                locations.push_back(std::make_pair(i, j));
            }
        }
    }
    if (locations.empty()) {
        locations.push_back(std::make_pair(-1, -1));
    }
    return locations;
}

void Display_Locations(std::vector<std::pair<int, int>> locations) {
    if (locations[0].first == -1) {
        std::cout << "The 2D vector contains no even numbers." << std::endl;
    }
    else {
        for (int i = 0; i < locations.size(); i++) {
            std::cout << "Row: " << locations[i].first << ", Column: " << locations[i].second << std::endl;
        }
    }
}


using namespace std;

vector<int>search(vector<int>& data) {
    vector<int>result(10, -1);
    int count = 0;
    for (int i = 0; i < 20; i++) {
        for (int j = 0; j < 10; j++) {
            if (data[i] == j) {
                result[count] = i;
                count++;
            }
        }
    }
    return result;
}

void displayLocation(vector<int>& result) {
    int count = 0;
    for (int i = 0; i < 10; i++) {
        if (result[i] != -1) {
            count++;
            cout << "Number " << i << " found at row " << result[i] / 5 << " and column " << result[i] % 5 << endl;
        }
    }
    if (count == 0) {
        cout << "No even numbers found." << endl;
    }
}

int main() {
    vector<int> a1 = { 11,1,3,1,5,1,1,3,1,5,1,1,3,1,5,1,1,3,1,5 };

    vector<int> data = { 1,2,1,4,5,6,1,9,10,1,2,1,2,2,2,1,2,1,2,2 };

    vector<int> result1 = search(a1);

    cout << "Locations of even numbers in a1: " << endl;
    displayLocation(result1);

    vector<int> result2 = search(data);

    cout << "Locations of even numbers in data: " << endl;
    displayLocation(result2);

    return 0;
}
