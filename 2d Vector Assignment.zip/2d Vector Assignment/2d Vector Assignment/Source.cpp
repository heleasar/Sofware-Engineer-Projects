#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <sstream>

using namespace std;

struct GoogleTrendData {
    string date;
    int count;
};

vector<GoogleTrendData> readDataFromFile(string filename) {
    vector<GoogleTrendData> data;
    ifstream inputFile(filename);
    if (!inputFile.is_open()) {
        cout << "Error opening input file: " << filename << endl;
        return data;
    }
 
    string line;
    getline(inputFile, line);
    while (getline(inputFile, line)) {
       
        size_t pos = line.find(',');
        string date = line.substr(0, pos);
        int count = stoi(line.substr(pos + 1));
        data.push_back({ date, count });
    }
    inputFile.close();
    return data;
}

void writeDataToFile(string filename, vector<GoogleTrendData> data) {
    ofstream outputFile(filename);
    if (!outputFile.is_open()) {
        cout << "Error opening input file. " << filename << endl;
        return;
    }
    outputFile << "Date,Count" << endl;
    for (auto row : data) {
        outputFile << row.date << "," << row.count << endl;
    }
    outputFile.close();
}

bool compareTrendData(GoogleTrendData a, GoogleTrendData b) {
    return a.count > b.count;
}

int main() {
    vector<GoogleTrendData> data = readDataFromFile("SortedMultiTimeline.csv");
    if (data.empty()) {
        return 1;
    }
    sort(data.begin(), data.end(), compareTrendData);
    writeDataToFile("sortedTrends.csv", data);
    return 0;
}
